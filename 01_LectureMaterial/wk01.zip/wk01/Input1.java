/**
 *  This program does something like the HelloWorld example
 *  except that it prints the first argument (which must be present
 *  otherwise there will be an error).
 *
 *  @author  Manfred Kerber
 *  @version 2014-09-27
 */

public class Input1 { 
   public static void main(String[] args)  {
       System.out.println(args[0]);
   }
}
