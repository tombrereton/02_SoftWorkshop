/** If the string is to contain the " itself, it has to be escaped by a 
 *  backslash sign.
 *
 *  @author  Manfred Kerber
 *  @version 2014-09-27
 *
 */


public class String2 { 
    public static void main(String[] args) {
       System.out.println("\"Hallo, Welt!\" is the German equivalent of \"Hello, World!\".");
   }
}

