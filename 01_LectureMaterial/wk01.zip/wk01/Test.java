public class Test
{ 
    public static void main(String[] args)
   {
       System.out.println( 8 * 4 / 2 * 2);
       System.out.println( 8 / 4 / 2 * 2);
       System.out.println( 8 * 4 / 2 / 2);
       System.out.println( 8 / 4 / 2 * 2);
   }
}
