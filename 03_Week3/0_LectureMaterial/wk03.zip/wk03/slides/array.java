int length = 100;
int[] a = new int[length];
for (int i=0; i < length; i++){
    a[i] = i*i;
}
