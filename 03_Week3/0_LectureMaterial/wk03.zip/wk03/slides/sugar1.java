int a,b;
a = 10;
b = 10;

a += 5;  // += adds the value of the 
         // term to the right to the variable
b = b+5;

a -= 10; // -= subtracts the value of the
         // term to the right from the variable
b = b-10;
