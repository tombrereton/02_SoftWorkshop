a--;    // decreases the value of the term by 1
b = b - 1;

a++;    // increases the value of the term by 1
b = b + 1;

(a == b) // tests for pointer equality

// != stands for not equal      
System.out.println("!(a == b) ==>    " + !(a == b));
System.out.println("(a != b)  ==>    " + (a != b));
